import 'package:flutter/material.dart';
import 'package:english_words/english_words.dart';

void main() 
{
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) 
  {
    return MaterialApp(
      title: 'Startup Name Generator',
      theme: ThemeData(
        appBarTheme: const AppBarTheme
        (
          foregroundColor: Color.fromARGB(255, 255, 255, 255),
          backgroundColor: Colors.deepPurple,
        ),
      ),
      home: const RandomWords(),
    );
  }
}

class RandomWords extends StatefulWidget {
  const RandomWords({Key? key});
  @override
  State<RandomWords> createState() => _RandomWordsState();
}

class LoginWindow extends StatelessWidget {
  LoginWindow({key});
  final TextEditingController email = TextEditingController();
  final TextEditingController password = TextEditingController();

  @override
  Widget build(BuildContext context) 
  {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),),

      body: Padding(
        padding: const EdgeInsets.all(60.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            const Text('Welcome to Startup Names Generator, please log in!'),
            TextFormField(
              controller: email,
              decoration: const InputDecoration(labelText: 'Email'),
            ),

            TextFormField(
              controller: password,
              decoration:const InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),

            Padding(
              padding: const EdgeInsets.only(top: 35.0),
              child: Container(
                height: 35.0,
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () 
                  {
                    ScaffoldMessenger.of(context).showSnackBar
                    (   
                      const SnackBar(
                        content: Text('Login is not implemented yet.'),
                        backgroundColor: Color.fromARGB(255, 72, 14, 97)
                    ),);
                  },
                  
                  
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.deepPurple,  
                  ),
                  child: const Text('Log in'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RandomWordsState extends State<RandomWords> {
  void _pushSaved() 
  {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) {
          final tiles = _saved.map(
            (pair) 
            {
              return Dismissible(
                key: ValueKey(pair),
                background: Container(
                  color: Colors.deepPurple,
                  child:const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 50),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Icon(Icons.delete, color: Colors.white),
                        Text("Delete Suggestion", style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),
                ),

                  secondaryBackground: Container( 
                  color: Colors.deepPurple,
                  child:const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 50),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text("Delete Suggestion", style: TextStyle(color: Colors.white)),
                        Icon(Icons.delete, color: Colors.white),
                      ],
                    ),
                  ),
                ),
                
                onDismissed: (direction) 
                {
                  setState(() 
                  {
                    _saved.remove(pair);
                  });
                },

                confirmDismiss: (direction) async 
                {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                    content: Text('Deletion is not implemented yet.'),
                    backgroundColor: Color.fromARGB(255, 72, 14, 97)), 
                  );
                  return false; 
                },

                child: ListTile(
                  title: Text(
                    pair.asPascalCase,
                    style: _biggerFont,
                  ),
                ),
              );
            },
          );

          final divided = tiles.isNotEmpty
              ? ListTile.divideTiles(
                  context: context,
                  tiles: tiles,
                ).toList()
              : <Widget>[];

          return Scaffold(
            appBar: AppBar(
              title: const Text('Saved Suggestions'),
            ),
            body: ListView(children: divided),
          );
        },
      ),
    );
  }

  final _suggestions = <WordPair>[];
  final _saved = <WordPair>{};
  final _biggerFont = const TextStyle(fontSize: 18);

  @override
  Widget build(BuildContext context) 
  {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Startup Name Generator'),
        actions: [
          IconButton(
            icon: const Icon(Icons.star),
            color: Colors.yellow,
            onPressed: _pushSaved,
            tooltip: 'Saved Suggestions',
          ),

          IconButton(
            icon: const Icon(Icons.login),
            color: Colors.white,
            onPressed: ()
             {
                Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LoginWindow()),
                );
            },
          ),
        ],
      ),
      
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemBuilder: (context, i) 
        {
          if (i.isOdd) return const Divider();
          final index = i ~/ 2;
          if (index >= _suggestions.length) 
          {
            _suggestions.addAll(generateWordPairs().take(10));
          }

          final alreadySaved = _saved.contains(_suggestions[index]);
          return ListTile(
            title: Text(
              _suggestions[index].asPascalCase,
              style: _biggerFont,
            ),

            trailing: Icon(
              alreadySaved ? Icons.favorite : Icons.favorite_border,
              color: alreadySaved ? Colors.red : null,
              semanticLabel: alreadySaved ? 'Remove from saved' : 'Save',
            ),

            onTap: () 
            {
              setState(() 
              {
                if (alreadySaved) 
                {
                  _saved.remove(_suggestions[index]);
                } else {
                  _saved.add(_suggestions[index]);
                }
              });
            },
          );
        },
      ),
    );
  }
}

